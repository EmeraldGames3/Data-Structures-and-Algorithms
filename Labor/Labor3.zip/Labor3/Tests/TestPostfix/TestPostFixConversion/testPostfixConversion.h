#pragma once

void testInfixConversion();