#pragma once
#include "StackTest.h"

void testStack();