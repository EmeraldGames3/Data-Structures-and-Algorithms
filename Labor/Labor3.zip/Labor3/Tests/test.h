#pragma once

#include "TestStack//StackTest.h"
#include "TestQueue/ExtendedTest.h"
#include "TestQueue/ShortTest.h"

void test();