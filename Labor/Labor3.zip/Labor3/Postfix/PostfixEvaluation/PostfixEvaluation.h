#pragma once

#include "../../Queue/Queue.h"
#include "../../Stack/Stack.h"
#include <string>

using std::string;

int evaluatePostfixExpression(const string &expression);