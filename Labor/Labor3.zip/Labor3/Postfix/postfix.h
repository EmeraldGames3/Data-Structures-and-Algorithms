#pragma once

#include <string>
#include "PostfixEvaluation/PostfixEvaluation.h"
#include "PostfixConversion/PostFixConversion.h"

using std::string;

int postfix(const string &expression);