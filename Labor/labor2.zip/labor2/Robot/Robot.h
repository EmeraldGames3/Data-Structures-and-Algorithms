#pragma once
#include "../LocationQueue/LocationQueue.h"

Location findRobot(char** matrix, int rows, int columns);