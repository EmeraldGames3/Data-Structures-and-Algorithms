#pragma once

void testAllExtended();